<?php
include "server_connect/connect.php";

$sql = "select game.name, game.image2_URL, game.genre, game.description, game.overallScore
from game, buying, user
where game.game_id = buying.game_id
and buying.user_id = user.user_id
order by game.name;";
$Purchase_Game_Result = mysql_query($sql, $connect);

$sql = "select game.name, game.image1_URL, buying.buy_date
from game, buying, user
where game.game_id = buying.game_id
and buying.user_id = user.user_id
order by buy_date desc
limit 3;";
$recent_Purchase_Game_Result = mysql_query($sql, $connect);

$sql = "select distinct game.name, game.image3_URL, game.overallScore, game.price
from game, buying
order by buying.buy_date
desc limit 3;";
$latest_Seller_Game_Result = mysql_query($sql, $connect);

?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <?php
    include "partial/meta.php";
    ?>

</head>
<body>
<!-- Page Preloder -->
<div id="preloder">
    <div class="loader"></div>
</div>

<?php
include "partial/menu.php";
?>

<!-- Page info section -->
<section class="page-info-section set-bg" data-setbg="img/page-top-bg/1.jpg">
    <div class="pi-content">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-6 text-white">
                    <h2>My Library</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Page info section -->


<!-- Page section -->
<section class="page-section recent-game-page spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="row">
                    <?php
                    while($Purchase_Game = mysql_fetch_array($Purchase_Game_Result)){
                        echo "<div class=\"col-md-6\">
                        <div class=\"recent-game-item\">
                            <div class=\"rgi-thumb set-bg\" data-setbg=$Purchase_Game[image2_URL]>
                                <div class=\"cata $Purchase_Game[genre]\">$Purchase_Game[genre]</div>
                            </div>
                            <div class=\"rgi-content\">
                                <h5>$Purchase_Game[game]</h5>
                                <p>$Purchase_Game[description]</p>
                                <p>Score : $Purchase_Game[overallScore]</p>
                            </div>
                        </div>
                    </div>";
                    }
                    ?>

                </div>
                <!--
                <div class="site-pagination">
                    <span class="active">01.</span>
                    <a href="#">02.</a>
                    <a href="#">03.</a>
                </div>
                -->
            </div>
            <!-- sidebar -->
            <div class="col-lg-4 col-md-7 sidebar pt-5 pt-lg-0">
                <!-- widget
                <div class="widget-item">
                    <form class="search-widget">
                        <input type="text" placeholder="Search">
                        <button><i class="fa fa-search"></i></button>
                    </form>
                </div>
                widget -->
                <div class="widget-item">
                    <h4 class="widget-title">Latest Purchase</h4>
                    <div class="latest-blog">
                        <?php
                        while($recent_Purchase_Game = mysql_fetch_array($recent_Purchase_Game_Result)){
                            echo "<div class=\"lb-item\">
                            <div class=\"lb-thumb set-bg\" data-setbg=$recent_Purchase_Game[image1_URL]></div>
                            <div class=\"lb-content\">
                                <div class=\"lb-date\">$recent_Purchase_Game[buy_date]</div>
                                <p>$recent_Purchase_Game[name]</p>
                            </div>
                        </div>";
                        }
                        ?>

                    </div>
                </div>


            </div>
        </div>
    </div>
</section>
<!-- Page section end -->


<?php
include "partial/latestSeller.php";
?>


<!-- Footer section -->
<footer class="footer-section">
    <div class="container">
        <ul class="footer-menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="sell.php">Games</a></li>
            <li><a href="library.php">Library</a></li>
            <li><a href="community.php">Forums</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
        <p class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
        </p>
    </div>
</footer>
<!-- Footer section end -->


<!--====== Javascripts & Jquery ======-->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.marquee.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>