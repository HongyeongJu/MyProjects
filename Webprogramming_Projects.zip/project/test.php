<!DOCTYPE html>
<html>
<head>
    <?php
    include "partial/meta.php";
    ?>
</head>
<body>

<?php
    include "partial/playlist.php";
?>


</body>
</html>