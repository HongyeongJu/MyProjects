<?php
/**
 * Created by PhpStorm.
 * User: kim2
 * Date: 2019-04-04
 * Time: 오전 9:39
 */

# TODO: MySQL DB에서, POST로 받아온 내용 입력하기!


include "../server_connect/connect.php";
$title = $_POST[title];
$main_text = $_POST[main_text];
$id = $_GET[id];


//사진 파일 넣기 .
// 사진 경로 설정

$uploads_picture = 'images/board';
$allowed_ext = array('jpg','jpeg','png','gif', 'JPG','JPEG','PNG','GIF', );
$uploads_file = 'file';

// 변수 정리
$error = $_FILES['mypic']['error'];
$name = $_FILES['mypic']['name'];
$ext = array_pop(explode('.' , $name));

// 파일 변수 정리
$file_error = $_FILES['myfile']['error'];
$file_name = $_FILES['myfile']['name'];
$file_ext = array_pop(explode('.' , $file_name));

//만약 사진첨부를 하였을때
if($error != UPLOAD_ERR_NO_FILE){
    echo "$name";

// 오류 확인
    if( $error != UPLOAD_ERR_OK ) {
        switch( $error ) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                echo "파일이 너무 큽니다.  over ($error)";
                break;
            case UPLOAD_ERR_NO_FILE:
                echo "파일이 첨부되지 않았습니다.  not ($error)";
                break;
            default:
                echo "파일이 제대로 업로드되지 않았습니다.  upload($error)";
        }
        exit;
    }

    if( !in_array($ext, $allowed_ext) ) {
        echo "허용되지 않는 확장자입니다. ";
        exit;
    }

    $name = uniqid("img-") . '.' .$ext;

// 파일 이동
    move_uploaded_file($_FILES['mypic']['tmp_name'], "../" . "$uploads_picture/$name");
}
// 파일 첨부를 하였을 때
if($file_error != UPLOAD_ERR_NO_FILE){
// 오류 확인
    if( $file_error != UPLOAD_ERR_OK ) {
        switch( $file_error ) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                echo "파일이 너무 큽니다.  over ($file_error)";
                break;
            case UPLOAD_ERR_NO_FILE:
                echo "파일이 첨부되지 않았습니다.  not ($file_error)";
                break;
            default:
                echo "파일이 제대로 업로드되지 않았습니다.  upload($file_error)";
        }
        exit;
    }

    $file_name = uniqid("file-") . '.' .$file_ext;

// 파일 이동
    move_uploaded_file($_FILES['myfile']['tmp_name'], "../" . "$uploads_file/$file_name");
}

$sql = "insert into writing(user_id, write_date, title, main_text, file_url, picture_url)".
 " values ('$id', now(), '$title', '$main_text', '$uploads_file/$file_name', '$uploads_picture/$name');";

echo $sql;

$result = mysql_query($sql,$connect);

if($result){
}
else {
    echo ("<script>alert('sql fail.');</script>");
}

mysql_close();
?>

<script>
    location.replace('../community.php');
</script>
