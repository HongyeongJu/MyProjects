<?php
/**
 * Created by PhpStorm.
 * User: Hong
 * Date: 2019-06-03
 * Time: ���� 3:20
 */

include "../server_connect/connect.php";

$board_num = $_GET[board_num];

$sql = "delete from writing where board_num = '$board_num';";

$result = mysql_query($sql, $connect);

if($result){

}else{
    echo "<script> alert('delete fail') </script>";
}
mysql_close();
?>

<script>
    location.replace('../community.php');
</script>
