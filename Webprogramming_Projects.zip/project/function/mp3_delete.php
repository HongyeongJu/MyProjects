<?php
/**
 * Created by PhpStorm.
 * User: kim2
 * Date: 2019-04-04
 * Time: 오전 9:39
 */

# TODO: MySQL DB에서, num에 해당하는 레코드 삭제하기!

include "../server_connect/connect.php";

$sql = "delete from playlist ".
    "where music_id = $_GET[music_id];";
// echo $sql;

$result = mysql_query($sql,$connect);

if($result){

}else{
    # 참고 : 에러 메시지 출력 방법
    echo "<script> alert('delete fail') </script>";
}
mysql_close();
?>

<script>
    location.replace('../mp3_index.php');
</script>
