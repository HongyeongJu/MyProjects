<?php
/**
 * Created by PhpStorm.
 * User: kim2
 * Date: 2019-04-04
 * Time: 오전 9:39
 */

# TODO: MySQL DB에서, num에 해당하는 레코드를 POST로 받아온 내용으로 수정하기!
include "../server_connect/connect.php";

$sql = "update playlist set name ='$_POST[name]' , music_URL = '$_POST[music_url]'  where music_id = '$_GET[music_id]';";

//echo $sql;
$result = mysql_query($sql,$connect);
if($result){
}
else {
    echo ("<script>alert('sql fail.');</script>");
}

mysql_close();

?>

<script>
     location.replace('../mp3_index.php');
</script>
