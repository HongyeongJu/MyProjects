<?php
/**
 * Created by PhpStorm.
 * User: Hong
 * Date: 2019-05-30
 * Time: 오후 9:13
 **/

  ob_start();

$filepath = "../" . $_GET[file_url];

echo $filepath;


$path_parts = pathinfo($filepath);
$filename = $path_parts['basename'];
$extension = $path_parts['extension'];

$file = $file_path; // 파일의 전체 경로
$file_name =  $filename; // 저장될 파일 이름

// 파일 다운로드 부분 오류 있음 수정 필요

header("Pragma: public");
header('Expires: 0');
header('Content-type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $file_name . '"');
header('Content-Transfer-Encoding: binary');
header('Content-Length: ' . filesize($file));

ob_clean();
flush();
readfile($filepath);

?>
