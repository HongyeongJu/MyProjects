<?php
include "server_connect/connect.php";
$count = 3;
if(isset($_GET[gameid])) {
    $count = 1;
}

$sql = "select * from game where game_id = $_GET[gameid];";
$get_Game = mysql_query($sql, $connect);

$game_Data = mysql_fetch_array($get_Game);

$sql = "select distinct game.name, game.image3_URL, game.overallScore, game.price
from game, buying
order by buying.buy_date
desc limit 3;";
$latest_Seller_Game_Result = mysql_query($sql, $connect);

?>
<!DOCTYPE html>
<html>
<meta charset='utf-8'>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <?php
    include "partial/meta.php";
    ?>

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

    <?php
    include "partial/menu.php";
    ?>

    <!-- Game template -->
    <link rel="stylesheet" href="game_template/css/otherstyles.css">
    <link rel="stylesheet" href="game_template/css/pawcarousel.css">
    <link rel="stylesheet" href="partial/bpopup.css" />

    <!-- Game template end-->


	<!-- Hero section -->
    <div class="master">
        <h2 class="game_title"><?php echo "$game_Data[name]"; ?></h2>

        <!--BEGIN PaW Carousel
            - copy and paste this
            - you may or may not want the 'master' class on the wrap - this is just the generic container class I use for the content width-->
        <section class="paw-carousel-wrap">
            <div class="paw-carousel">
                <div class="paw-carousel-items-wrap">

                    <?php
                    // 이미지 4장
                    for($index = 1; $index < 5; $index++){
                        $imageUrlIndex = 'image'.$index.'_URL';
                        echo "$imageUrlIndex";
                        echo"<div class=\"paw-carousel-item\">
                        <img src=\"images/x.gif\" data-src=$game_Data[$imageUrlIndex] data-src-2x=$game_Data[$imageUrlIndex] width=\"600\" height=\"370\" class=\"paw-carousel-item-media\">
                        <h3>$game_Data[name]</h3>
                    </div>";
                    }

                    // 동영상
                    echo "<div class=\"paw-carousel-item\">
                        <iframe width=\"560\" height=\"315\" src=$game_Data[movie_URL] frameborder=\"0\" allowfullscreen></iframe>
                    </div>";
                    ?>

                </div>
                <!--Next and previous links. SVGs - change with PNGs if you want browser support -->
                <a href="#" class="paw-carousel-prev"><img src="images/arr-prev.svg" alt="Previous"></a>
                <a href="#" class="paw-carousel-next"><img src="images/arr-next.svg" alt="Next"></a>
                <!--Left and right translucent masks - simply remove if not required-->
                <div class="paw-carousel-mask-l"></div>
                <div class="paw-carousel-mask-r"></div>
            </div>
            <!--Thumbnail navigation-->
            <nav class="paw-carousel-thumbs">
                <ul>
                    <?php
                    // 이미지 4장
                    for($index = 1; $index < 5; $index++){
                        $imageUrlIndex = 'image'.$index.'_URL';
                        echo"<li class=\"paw-carousel-nav-item\"><img src=$game_Data[$imageUrlIndex] width=\"100\" height=\"60\"></li>";
                    }

                    // 동영상
                    echo "<li class=\"paw-carousel-nav-item\"><img src=\"images/icn-play.png\" width=\"100\" height=\"60\><span class=\"paw-carousel-icn-thumb-vid\"></span></li>";
                    ?>

                </ul>
            </nav>
        </section>
        <!--END PaW Carousel-->

    </div>

	<!-- Recent game section  -->
	<section class="recent-game-section spad set-bg" data-setbg="img/recent-game-bg.png">
		<div class="container">
			<div class="section-title">
                <div class="game_description">
                    <?php
                    echo "$game_Data[description]";
                    ?>
                </div>
                <div class="game_explanation">
                    <?php
                    echo "<br>Genre : $game_Data[genre]<br> <br>
                    Usage_Grade : $game_Data[age_limit] Age<br> <br>
                    Price : $game_Data[price] Won<br> <br> <br> <br>";
                    ?>
                </div>

                <?php
                // 만약 접속해 있다면.
                if(isset($_SESSION[id])){
                    echo "<a id=\"buy-btn\">Buy</a>";
                }
                ?>
			</div>

		</div>
	</section>
	<!-- Recent game section end -->


    <?php
    include "partial/latestSeller.php";
    ?>


	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<ul class="footer-menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="sell.php">Games</a></li>
				<li><a href="library.php">Library</a></li>
				<li><a href="community.php">Forums</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<p class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
		</div>
	</footer>
	<!-- Footer section end -->

	<!--====== Javascripts & Jquery ======-->
    <?php
    include "partial/popup.php";
    include "partial/script.php";
    ?>

    </body>
</html>

