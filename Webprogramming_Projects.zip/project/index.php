<?php
include "server_connect/connect.php";

$sql = "select * from game order by rand() limit 3;";
$rand_Game_Result = mysql_query($sql, $connect);

$sql = "select * from game order by overallScore desc limit 4;";
$rank_Game_Result = mysql_query($sql, $connect);

$sql = "select * from game order by launch_date desc limit 3;";
$recent_Game_Result = mysql_query($sql, $connect);

$sql = "select distinct game.name, game.image3_URL, game.overallScore, game.price
from game, buying
order by buying.buy_date
desc limit 3;";
$latest_Seller_Game_Result = mysql_query($sql, $connect);
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <?php
    include "partial/meta.php";
    ?>

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

    <?php
    include "partial/menu.php";
    ?>

    <meta charset='utf-8'>
	<!-- Hero section -->
	<section class="hero-section">
		<div class="hero-slider owl-carousel">
            <?php
            while($rand_Game = mysql_fetch_array($rand_Game_Result)){
                echo "<div class=\"hs-item set-bg\" data-setbg=$rand_Game[image1_URL]>
				<div class=\"hs-text\">
					<div class=\"container\">
						<h2><span>$rand_Game[name]</span></h2>
						<p class='rand_game_description'>$rand_Game[description]</p>
						<a href=\"game.php?gameid=$rand_Game[game_id]\" class=\"site-btn\">Read More</a>
					</div>
				</div>
			</div>";
            }
            ?>

		</div>
	</section>
	<!-- Hero section end -->


	<!-- Latest news section
	<div class="latest-news-section">
		<div class="ln-title">Latest News</div>
		<div class="news-ticker">
			<div class="news-ticker-contant">
				<div class="nt-item"><span class="new">new</span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </div>
				<div class="nt-item"><span class="strategy">strategy</span>Isum dolor sit amet, consectetur adipiscing elit. </div>
				<div class="nt-item"><span class="racing">racing</span>Isum dolor sit amet, consectetur adipiscing elit. </div>
			</div>
		</div>
	</div>
	Latest news section end -->


	<!-- Recommend section
	<section class="feature-section spad">
		<div class="container">
			<div class="recommend">
				<div class="col-lg-3 col-md-6 p-0">
					<div class="feature-item set-bg" data-setbg="img/features/1.jpg">
						<span class="cata new">new</span>
						<div class="fi-content text-white">
							<h5><a href="#">Suspendisse ut justo tem por, rutrum</a></h5>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
							<a href="#" class="fi-comment">3 Comments</a>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 p-0">
					<div class="feature-item set-bg" data-setbg="img/features/2.jpg">
						<span class="cata strategy">strategy</span>
						<div class="fi-content text-white">
							<h5><a href="#">Justo tempor, rutrum erat id, molestie</a></h5>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
							<a href="#" class="fi-comment">3 Comments</a>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>
	Recommend section end -->


	<!-- Recent game section  -->
	<section class="recent-game-section spad set-bg" data-setbg="img/recent-game-bg.png">
		<div class="container">
			<div class="section-title">
				<div class="cata new">new</div>
				<h2>Recent Games</h2>
			</div>
			<div class="row">
                <?php
                while($recent_Game = mysql_fetch_array($recent_Game_Result)){
                    echo "<div class=\"col-lg-4 col-md-6\">
					<div class=\"recent-game-item\">
					<div class=\"cata new\">new</div>
						<a class='game_link' href='game.php?gameid=$recent_Game[game_id]'><div class=\"rgi-thumb set-bg\" data-setbg=$recent_Game[image2_URL]></div></a>
						<div class=\"rgi-content\">
							<h5><a class='game_link' href='game.php?gameid=$recent_Game[game_id]'>$recent_Game[name]</a></h5>
							<p>$recent_Game[description]</p>
							<a href=\"game.php?gameid=$recent_Game[game_id]\" class=\"comment\">$recent_Game[price] Won</a>
							<div class=\"rgi-extra\">
								<div class=\"rgi-star\"><img src=\"img/icons/star.png\" alt=\"\"></div>
								<div class=\"rgi-heart\"><img src=\"img/icons/heart.png\" alt=\"\"></div>
							</div>
						</div>
					</div>	
				</div>";
                }
                ?>


			</div>
		</div>
	</section>
	<!-- Recent game section end -->


	<!-- Rank game section -->
	<section class="review-section spad set-bg" data-setbg="img/review-bg.png">
		<div class="container">
			<div class="section-title">
				<div class="cata hot">Hot</div>
				<h2>Ranking Games</h2>
			</div>
			<div class="row">
                <?php
                while($rank_Game = mysql_fetch_array($rank_Game_Result)){
                    echo "<div class=\"col-lg-3 col-md-6\">
					<div class=\"review-item\">
					<div class=\"score green\">$rank_Game[overallScore]</div>
					<a class='game_link' href='game.php?gameid=$rank_Game[game_id]'>
						<div class=\"review-cover set-bg\" data-setbg=$rank_Game[image3_URL]>
						</div></a>
						<div class=\"review-text\">
							<h5><a class='game_link' href='game.php?gameid=$rank_Game[game_id]'>$rank_Game[name]</a></h5>
							<p>$rank_Game[description]</p>
						</div>
					</div>
				</div>";
                }

                ?>
			</div>
		</div>
	</section>
	<!-- Rank game section end -->


    <?php
    include "partial/latestSeller.php";
    ?>

	
	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<ul class="footer-menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="sell.php">Games</a></li>
				<li><a href="library.php">Library</a></li>
				<li><a href="community.php">Forums</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<p class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
		</div>
	</footer>
	<!-- Footer section end -->


	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.marquee.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>

