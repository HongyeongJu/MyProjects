<!DOCTYPE html>
<html>
<head>
    <?php
        include "partial/meta.php";
    ?>
</head>
<body>

<iframe src="index.php" style="width:100%; height: 99vh" frameborder="0" ></iframe>
<iframe src="test.php" style="    position: absolute; width: 350px; height: 81px; top: 554px; right: 30px;" frameborder="0" scrolling="no"></iframe>
<iframe src="dist/chat/chat.php" style="position: absolute; width:400px; height: 450px; top: 100px; right: 10px;" frameborder="0" scrolling="no"></iframe>

</body>
</html>