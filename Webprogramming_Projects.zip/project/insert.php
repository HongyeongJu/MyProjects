<?php
    include "server_connect/connect.php";

    $myid = $_SESSION[id];
    // board_num이 있는 경우 (즉 수정을 원하는 경우)
    if(isset($_GET[board_num])){
        $update_bool = true;

        $board_num = $_GET[board_num];

        $sql = "select * from writing where board_num = '$board_num';";

        $result = mysql_query($sql , $connect);

        $row = mysql_fetch_array($result);
        // sql문 변수 설정
        $writer_id = $row[user_id];
        $write_date = $row[write_date];
        $title = $row[title];
        $main_text = $row[main_text];
        $file_url = $row[file_url];
        $picture_url = $row[picture_url];


        // 수정을 원하는
    }
?>

<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Game Warrior Template</title>
	<meta charset="UTF-8">
	<meta name="description" content="Game Warrior Template">
	<meta name="keywords" content="warrior, game, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include "partial/meta.php";
    ?>

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

    <?php
    include "partial/menu.php";
    ?>


	<!-- Latest news section -->
	<div class="latest-news-section">
		<div class="ln-title">Latest News</div>
		<div class="news-ticker">
			<div class="news-ticker-contant">
				<div class="nt-item"><span class="new">new</span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </div>
				<div class="nt-item"><span class="strategy">strategy</span>Isum dolor sit amet, consectetur adipiscing elit. </div>
				<div class="nt-item"><span class="racing">racing</span>Isum dolor sit amet, consectetur adipiscing elit. </div>
			</div>
		</div>
	</div>
	<!-- Latest news section end -->


	<!-- Page info section -->
	<section class="page-info-section set-bg" data-setbg="img/page-top-bg/2.jpg">
		<div class="pi-content">
			<div class="container">
				<div class="row">
				</div>
			</div>
		</div>
	</section>
	<!-- Page info section -->


    <style>
        .filebox label{
            display: inline-block;
            padding: .5em .75em;
            color: #ffffff;
            font-size: inherit;
            line-height: normal;
            vertical-align: middle;
            background-color: #2aabd2;
            cursor: pointer;
            border: 1px solid #ebebeb;
            border-bottom-color: #e2e2e2;
            border-radius: .25em;
        }

        .filebox input[type="file"]{
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip:rect(0,0,0,0);
            border: 0;
        }
    </style>

	<!-- Page section -->
	<section class="page-section single-blog-page spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-8">
					<div class="comment-form-warp">
						<h4 class="comment-title">
                            <?php
                            if($update_bool) {
                                echo "update";
                            }else {
                                echo "add";
                            }
                            ?></h4>

                        <?php
                        /*
                            if($update_bool && strlen($picture_url) > 13){
                                echo "<img id='writing_iamge' alt='' src='$picture_url' style='margin-bottom : 10px;'>";
                            }else {
                                echo "<img id='writing_image' alt='' src='#' style='display : none; margin-bottom: 10px;'>";
                            }
                        */
                        echo "<img id='writing_image' alt='' src='#' style='display : none; margin-bottom: 10px;'>";
                        ?>
                        <?php
                        //수정하기라면
                            if($update_bool){
                                echo "<form class='comment-form' action='function/board_update.php?board_num=$board_num' method='POST' enctype='multipart/form-data'>";
                            }else {
                                echo "<form class='comment-form' action='function/board_insert.php?id=$myid' method='POST'  enctype='multipart/form-data'>";
                            }
                        ?>
							<div class="row">
								<div class="col-lg-12">
                                    <?php
                                    // 수정하기라면
                                    if($update_bool){
                                        echo "<input type='text' placeholder='title' name='title' value='$title'>";
                                        echo "<textarea placeholder='main_text' name='main_text' >$main_text</textarea>";
                                    }else {// 게시하기라면
                                        echo "<input type='text' placeholder='title' name='title' >";
                                        echo "<textarea placeholder='main_text' name='main_text'></textarea>";
                                    }
                                    ?>
                                    <div class="filebox">
                                        <label for="ex_picture">picture upload</label>
                                        <?php
                                        //수정하기라면
                                        /*
                                            if($update_bool){
                                                echo "<input type='file' id='ex_picture' name='mypic' value='$picture_url'>";
                                            }else {
                                                echo "<input type='file' id='ex_picture' name='mypic'>";
                                            }
                                        */

                                        echo "<input type='file' id='ex_picture' name='mypic'>";
                                        ?>
                                        <label for="ex_file">file upload</label>
                                        <?php
                                        //수정하기라면
                                        /*
                                            if($update_bool){
                                                echo "<input type='file' id='ex_file' name='myfile' value='$file_url'>";
                                            }else {
                                                echo "<input type='file' id='ex_file' name='myfile'>";
                                            }
                                        */
                                        echo "<input type='file' id='ex_file' name='myfile'>";
                                        ?>
                                    </div>
                                    <button class="site-btn btn-sm" type="submit">
                                        <?php
                                            if($update_bool){
                                                echo "update";
                                            }else {
                                                echo "add";
                                            }
                                        ?></button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Page section end -->

	
	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<ul class="footer-menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="review.html">Games</a></li>
				<li><a href="categories.php">Blog</a></li>
				<li><a href="community.php">Forums</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<p class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
		</div>
	</footer>
	<!-- Footer section end -->


	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.marquee.min.js"></script>
	<script src="js/main.js"></script>


    <!-- 사진을 등록할 때 사진 모양을 바꾸게 하기 -->
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#writing_image').attr('src', e.target.result);
                    $('#writing_image').css('display', 'block');
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#ex_picture").change(function() {
            readURL(this);
        });
    </script>

    </body>
</html>