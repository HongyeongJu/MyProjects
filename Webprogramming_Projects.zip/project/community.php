<?php
session_start();


$connect = mysql_connect("localhost", "game_admin", "123");
mysql_select_db("game_flatform_db", $connect);

$sql = "select count(*) as count from writing;";
$result = mysql_query($sql, $connect);

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Game Warrior Template</title>
	<meta charset="UTF-8">
	<meta name="description" content="Game Warrior Template">
	<meta name="keywords" content="warrior, game, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include "partial/meta.php";
    ?>

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

    <?php
    include "partial/menu.php";
    ?>



	<!-- Page info section -->
	<section class="page-info-section set-bg" data-setbg="img/page-top-bg/4.jpg">
		<div class="pi-content">
			<div class="container">
				<div class="row">
					<div class="col-xl-5 col-lg-6 text-white">
						<h2>free bulletin</h2>
						<p>Talk to your friend freely!~</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Page info section -->


	<!-- Page section -->
	<section class="page-section community-page set-bg" data-setbg="img/community-bg.jpg">
		<div class="community-warp spad">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<h3 class="community-top-title">All bullet-in count :
                            <?php
                            $row = mysql_fetch_array($result);
                            $total_items = $row[count];
                            echo $total_items;
                            ?></h3>
					</div>
				</div>
				<ul class="community-post-list">

                    <?php
                    $item_per_page = 3;
                    $num_page_button = 5;
                    $total_page = ceil($total_items / $item_per_page);
                    if(isset($_GET[p])){
                        $current_page = $_GET[p];
                    }else {
                        $current_page = 0;
                    }

                    $start = $current_page * $item_per_page;

                    if($total_page > $current_page + $num_page_button)
                        $display_pagenum = $_num_page_button;
                    else
                        $display_pagenum = $total_page - $current_page;

                    $sql = "select * from writing limit $start, $item_per_page";
                    $result = mysql_query($sql, $connect);

                    while($row = mysql_fetch_array($result)){
                        $board_num = $row[board_num];
                        $board_id = $row[board_id];
                        $user_id = $row[user_id];
                        $write_date = $row[write_date];
                        $title = $row[title];
                        $main_text = $row[main_text];
                        $file_url = $row[file_url];
                        $picture_url = $row[picture_url];

                        echo "<a href='board_read.php?board_id=$board_num&user_id=$user_id'>";
                        echo "<li>";
                        echo "<div class='community-post'>";

                        if(strlen($file_url) <=5){
                            echo "<div class='author-avator set-bg' data-setbg=''></div>";
                        }else {
                            echo "<div class='author-avator set-bg' data-setbg='img/floppy-disk.jpg' style='background-color: #FFFFFF;'></div>";
                        }
                        echo "<div class='post-content'>";
                        echo "<h5>$user_id<span>posted an update</span></h5>";
                        echo "<div class='post-date'>$write_date</div>";
                        echo "<p style='font-size: 30px;'>$title </p>";
                        if(isset($picture_url)){
                            echo "<div class='attachment-file'>";
                            echo			"<img src='$picture_url' alt=''>";
                            echo           "</div>";
                        }
                        echo "</div>";
                        echo "</div>";
                        echo "</li>";
                        echo "</a>";
                    }
                    ?>
				</ul>
				<div class="site-pagination sp-style-2" style="text-align: center;">

                    <?php
                        if($current_page != 0) {
                            $prev_page = $current_page -1;
                            echo "<a href='community.php?p=0'> << </a>";
                            echo "<a href='community.php?={$prev_page}'> < </a>";
                        }
                    ?>
                    <?php
                        for($i = $current_page; $i <($current_page + $display_pagenum) ; $i++) {
                            $page = $i + 1;
                            if($current_page == $i)
                                echo "<a class='active' href='community.php?p={$i}'> {$page} </a>";
                            else
                                echo "<a href='community.php?p={$i}'> {$page} </a>";
                        }
                    ?>
                    <?php
                        if($current_page < $total_page - 1) {
                            $next_page = $current_page +1;
                            $final_page = $total_page - 1;
                            echo "<a href='community.php?p={$next_page}'> > </a>";
                            echo "<a href='community.php?p={$final_page}'> >></a>";
                        }
                    ?>
				</div>
                <?php
                // 만약 접속해 있다면.
                    if(isset($_SESSION[id])){
                        echo "<div class='user-panel'>";
                        echo "<a href='insert.php?id=$_SESSION[id]'>추가하기</a>";
                        echo "</div>";
                    }
                ?>
			</div>
		</div>
	</section>
	<!-- Page section end -->

	
	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<ul class="footer-menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="review.html">Games</a></li>
				<li><a href="categories.php">Blog</a></li>
				<li><a href="community.php">Forums</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<p class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
		</div>
	</footer>
	<!-- Footer section end -->


	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.marquee.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html lang="en">