<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Au Register Forms by Colorlib</title>


    <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.6/mediaelementplayer.css">
    <link rel="stylesheet" href="dist/playlist/playlist.css">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="shortcut icon"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i" rel="stylesheet">

    <!-- Stylesheets -->

    <link rel="stylesheet" href="css/font-awesome.min.css"/>
    <link rel="stylesheet" href="css/owl.carousel.css"/>
    <link rel="stylesheet" href="css/style.css"/>
    <link rel="stylesheet" href="css/animate.css"/>


    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->


    <!-- Icons font CSS-->
    <link href="colorlib-regform-4/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="colorlib-regform-4/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="colorlib-regform-4/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="colorlib-regform-4/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="colorlib-regform-4/css/main.css" rel="stylesheet" media="all">
</head>

<body>

<style>
    .container .menus {
        display: inline-block;
        font-size: 16px;
        color: #fff;
        margin-left: 35px;
        font-weight: 500;
        padding: 10px 5px;
        text-decoration: none;
        height: 47px;
    }

    .container a{
        text-decoration: none;
        font-family: 'Roboto', sans-serif;
        -webkit-font-smoothing: antialiased;
    }

</style>
<!-- Header section -->
<header class="header-section" style="padding : 21px; padding-left: 20%;">
    <div class="container">
        <!-- logo -->
        <a class="site-logo" href="index.html">
            <img src="img/logo.png" alt="">
        </a>

        <?php
        if(isset($_SESSION[id])){
            echo "<div class='user-panel' style='line-height: 1.5;'>$_SESSION[id]님 환영합니다.";
            echo "<a href='function/logout.php' >Logout</a>";
            echo "</div>";
        }
        else {
            echo "<div class='user-panel' style='line-height: 1.5;'>";
            echo "<a href ='login.php'>Login</a> / <a href='signup.php' >Register</a>";
            echo "</div>";
        }

        ?>
        <!-- responsive -->
        <div class="nav-switch">
            <i class="fa fa-bars"></i>
        </div>
        <!-- site menu -->
        <nav class="main-menu">
            <ul>
                <li><a class='menus' href="index.php">Home</a></li>
                <li><a class='menus' href="review.php">Games</a></li>
                <li><a class='menus' href="categories.php">Blog</a></li>
                <li><a class='menus' href="community.php">Forums</a></li>
                <li><a class='menus' href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </div>
</header>
<!-- Header section end -->
    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w680">
            <div class="card card-4">
                <div class="card-body">
                    <h2 class="title">Registration Form</h2>
                    <form method="POST" action="function/signup.php">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label" >아이디</label>
                                    <input class="input--style-4" type="text" name="id">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">이름</label>
                                    <input class="input--style-4" type="text" name="name">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">비밀번호</label>
                                    <input class="input--style-4" type="password" name="password">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">비밀번호 확인</label>
                                    <input class="input--style-4" type="password" name="password2">
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">생일</label>
                                    <div class="input-group-icon">
                                        <input class="input--style-4 js-datepicker" type="text" name="age">
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">성별</label>
                                    <div class="p-t-10">
                                        <label class="radio-container m-r-45">남자
                                            <input type="radio" checked="checked" name="sex" value="0">
                                            <span class="checkmark"></span>
                                        </label>
                                        <label class="radio-container">여자
                                            <input type="radio" name="sex" value="1">
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">주소</label>
                                    <input class="input--style-4" type="text" name="address">
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">핸드폰 번호</label>
                                    <input class="input--style-4" type="tel" name="phone" pattern="[0-9]{3]-[0-9]{4}-[0-9]{4} required">
                                </div>
                            </div>
                        </div>

                        <div class="p-t-15">
                            <button class="btn btn--radius-2 btn--blue" type="submit">회원가입</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <?php
        include "partial/bottom_meta.php";
    ?>
    <!-- Jquery JS-->
    <script src="colorlib-regform-4/vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="colorlib-regform-4/vendor/select2/select2.min.js"></script>
    <script src="colorlib-regform-4/vendor/datepicker/moment.min.js"></script>
    <script src="colorlib-regform-4/vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="colorlib-regform-4/js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->