<?php
    include "server_connect/connect.php";

    $myid = $_SESSION[id];


?>

<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Game Warrior Template</title>
	<meta charset="UTF-8">
	<meta name="description" content="Game Warrior Template">
	<meta name="keywords" content="warrior, game, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include "partial/meta.php";
    ?>

    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/vendor/perfect-scrollbar/perfect-scrollbar.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/css/util.css">
    <link rel="stylesheet" type="text/css" href="mp3_table/css/main.css">
    <!--===============================================================================================-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

    <?php
    include "partial/menu.php";
    ?>


    <div class="limiter">
        <div class="container-table100">
            <div class="wrap-table100">
                <a href="mp3_board_form.php" style="border: 1px; padding: 10px; background: #36304a; display: block; width: 100px; text-align: center; float: right; border-radius: 10px; margin-bottom: 5px;"> Add </a>
                <div class="table100">
                    <table>
                        <thead>
                        <tr class="table100-head">
                            <th class="column2">Name </th>
                            <th class="column3">Music URL</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        # TODO : 아래 표시되는 내용을, MySQL 테이블에 있는 레코드로 대체하기!
                        # Note : column6 에 해당하는 Total 은 Price 값과 Quantity 값의 곱으로 표시!
                        $sql = "select * from playlist;";
                        $result = mysql_query($sql,$connect);

                        while($row = mysql_fetch_array($result)){
                            echo "<tr onclick=\"location.href = ('mp3_board_form.php?music_id=$row[music_id]')\">";
                            echo ("<td class=\"column2\">$row[name]</td>");
                            echo ("<td class=\"column3\">$row[music_URL]</td>");
                            echo ("</tr>");
                        }

                        mysql_close();
                        ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
	
	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<ul class="footer-menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="review.html">Games</a></li>
				<li><a href="categories.php">Blog</a></li>
				<li><a href="community.php">Forums</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<p class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
		</div>
	</footer>
	<!-- Footer section end -->


	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.marquee.min.js"></script>
	<script src="js/main.js"></script>


    <!--===============================================================================================-->
    <script src="mp3_table/vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="mp3_table/vendor/bootstrap/js/popper.js"></script>
    <script src="mp3_table/vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="mp3_table/vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="mp3_table/js/main.js"></script>



    </body>
</html>