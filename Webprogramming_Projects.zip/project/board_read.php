<?php
include "server_connect/connect.php";
$myid = $_SESSION[id];
$board_num = $_GET[board_id];
$user_id = $_GET[user_id];
//$download_on = $_GET[file_download];
//
//$download_switch = strcmp($download_on, "on");

//sql 문

$sql = "select * from writing where board_num = '$board_num';";
$result = mysql_query($sql, $connect);

$row = mysql_fetch_array($result);

// sql 문 변수 설정
$writer_id = $row[user_id];
$write_date = $row[write_date];
$title = $row[title];
$main_text = $row[main_text];
$file_url = $row[file_url];
$picture_url = $row[picture_url];



?>

<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Game Warrior Template</title>
	<meta charset="UTF-8">
	<meta name="description" content="Game Warrior Template">
	<meta name="keywords" content="warrior, game, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include "partial/meta.php";
    ?>

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

    <?php
    include "partial/menu.php";
    ?>


	<!-- Latest news section -->
	<div class="latest-news-section">
		<div class="ln-title">Latest News</div>
		<div class="news-ticker">
			<div class="news-ticker-contant">
				<div class="nt-item"><span class="new">new</span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </div>
				<div class="nt-item"><span class="strategy">strategy</span>Isum dolor sit amet, consectetur adipiscing elit. </div>
				<div class="nt-item"><span class="racing">racing</span>Isum dolor sit amet, consectetur adipiscing elit. </div>
			</div>
		</div>
	</div>
	<!-- Latest news section end -->


	<!-- Page info section -->
	<section class="page-info-section set-bg" data-setbg="img/page-top-bg/2.jpg">
		<div class="pi-content">
			<div class="container">
				<div class="row">
					<div class="col-xl-5 col-lg-6 text-white">
						<h2><?php echo "$title";
						?></h2>

					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Page info section -->

<!-- 수정할 부분~~~~~-->
	<!-- Page section -->


	<section class="page-section single-blog-page spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-8">

                    <?php
                        if(strlen($picture_url) > 13){
                            echo "<div class='blog-thumb set-bg' data-setbg='$picture_url'>";
//                            echo "    <div class='cata new'>new</div>";
//                            echo "    <div class='rgi-extra'>";
//                            echo "        <div class='rgi-star'><img src='img/icons/star.png' alt=''></div>";
//                            echo "        <div class='rgi-heart'><img src='img/icons/heart.png' alt=''></div>";
//                            echo "    </div>";
                            echo "</div>";
                        }
                        if(strlen($file_url) > 5){
                            echo "<a href='function/file_download.php?file_url=$file_url'>";
                            echo "<img src='img/floppy-disk.jpg' alt='파일이미지' style='width: 30px;'>";
                            echo "</a>";
                        }

                        echo "<div class=blog-content>";
                        echo "<p>";
                        echo "$main_text";
                        echo "</p>";
                    ?>

				</div>
                <?php
                // 만약 접속해 있는 id와 작성자 id가 같다면. 수정 및 삭제를 할 수 있도록 한다.

                $same_id = strcmp($myid , $writer_id);
                if($same_id){       // 다를 때
                    // 다를 때는 아무 것도 처리 하지 않는다.
                }else{      // 같을 때
                    // 같을 때는 수정하기 , 삭제하기 버튼을 만든다.
                    echo "<div class='user-panel'>";
                    echo "<a href='insert.php?board_num=$board_num'>update</a>";
                    echo "</div>";

                    echo "<div class='user-panel'>";
                    echo "<a href='function/board_delete.php?board_num=$board_num'>delete</a>";
                    echo "</div>";
                }
                ?>
			</div>
		</div>
	</section>
	<!-- Page section end -->

	
	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<ul class="footer-menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="review.html">Games</a></li>
				<li><a href="categories.php">Blog</a></li>
				<li><a href="community.php">Forums</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<p class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
		</div>
	</footer>
	<!-- Footer section end -->


	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.marquee.min.js"></script>
	<script src="js/main.js"></script>
    </body>
</html>