
<div id="element_to_pop_up">
    <?php
    $randomNum = mt_rand(10000, 99999);
    echo "<div>전용계좌<br><br>
    신한은행 123-456-$randomNum</div>";
    ?>

</div>

<div id="upload_to_pop_up">
    <h3>Upload</h3>
    <form enctype='multipart/form-data' action="function/upload.php" method="POST">
        <input type='file' id="imgInp" name="imgInp"/>
        <img id="foo"src="#" />
        <input type="text" name="title" placeholder="title">
        <input type="text" name="description" placeholder="description">
        <input type="submit" value="Upload">
    </form>
</div>