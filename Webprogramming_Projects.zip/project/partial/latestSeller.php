<!-- Footer top section -->
<section class="footer-top-section">
    <div class="container">
        <div class="footer-top-bg">
            <img src="img/footer-top-bg.png" alt="">
        </div>
        <div class="row">

            <div class="col-lg-4">
                <div class="footer-logo text-white">
                    <img src="img/footer-logo.png" alt="">
                    <p>Game Distribution Platform</p>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="footer-widget mb-5 mb-md-0">
                    <h4 class="fw-title">Latest Seller</h4>
                    <div class="latest-blog">
                        <?php
                        while($latest_Seller_Game = mysql_fetch_array($latest_Seller_Game_Result)){
                            echo "<div class=\"lb-item\">
								<div class=\"lb-thumb set-bg\" data-setbg=$latest_Seller_Game[image3_URL]></div>
								<div class=\"lb-content\">
									<div class=\"lb-date\">$latest_Seller_Game[name]</div>
									<p>Score : $latest_Seller_Game[overallScore]<br>
									Price : $latest_Seller_Game[price] Won</p>
								</div>
							</div>";
                        }
                        ?>

                    </div>
                </div>
            </div>


        </div>
    </div>
</section>
<!-- Footer top section end -->