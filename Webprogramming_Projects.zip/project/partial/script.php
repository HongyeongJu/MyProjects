<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.marquee.min.js"></script>
<script src="js/main.js"></script>
<!--You can use jQuery 2.x as well if you don't want to support older browsers -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="game_template/js/pawcarousel.jquery.min.js"></script>
<script>
    $(function(){
        $('.paw-carousel').pawCarousel();
    });
</script>


<script src="partial/jquery.bpopup.min.js"></script>
<script>
    $('#buy-btn').click(function() {
        $('#element_to_pop_up').bPopup();
    });
</script>