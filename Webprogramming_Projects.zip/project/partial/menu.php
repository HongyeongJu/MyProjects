<?php

$connect = mysql_connect("localhost", "game_admin", "123");
mysql_select_db("game_flatform_db", $connect);
    $myid = $_SESSION[id];

    $sql = "select * from user where user_id = '$myid';";

    $result2 = mysql_query($sql, $connect);

    if(isset($result2)){
        $row2 = mysql_fetch_array($result2);
    }

?>

<!-- Header section -->
<style>
    .container .menus {
        display: inline-block;
        font-size: 16px;
        color: #fff;
        margin-left: 35px;
        font-weight: 500;
        padding: 10px 5px;
        text-decoration: none;

    }

    .container a{
        text-decoration: none;
        font-family: 'Roboto', sans-serif;
        -webkit-font-smoothing: antialiased;
    }
</style>


<header class="header-section">
    <div class="container">
        <!-- logo -->
        <a class="site-logo" href="index.php">
            <img src="img/logo.png" alt="">
        </a>


        <style>
            .user-panel a:hover{
                color: #e74c3c;
            }
        </style>
        <?php
            if(isset($_SESSION[id])){
                echo "<div class='user-panel'>$_SESSION[id]님 환영합니다. ";
                echo "<a href='function/logout.php'> Logout</a>";
                echo "</div>";
            }
            else {
                echo "<div class='user-panel'>";
                echo "<a href ='login.php'>Login</a> / <a href='signup.php'>Register</a>";
                echo "</div>";
            }

        ?>
        <!-- responsive -->
        <div class="nav-switch">
            <i class="fa fa-bars"></i>
        </div>
        <!-- site menu -->
        <nav class="main-menu">
            <ul>
                <li><a class='menus' href="index.php">Home</a></li>
                <li><a class='menus' href="sell.php">Game</a></li>
                <?php
                    if(isset($_SESSION[id])){
                        echo "<li><a class='menus' href='library.php'>Library</a></li>";
                    }else {
                        echo "<li><a class='menus' href='login.php'>Library</a></li>";
                    }
                ?>
                <li><a class='menus' href="community.php">Forums</a></li>
                <li><a class='menus' href="contact.php">Contact</a></li>
                <?php
                //운영자 등급이면
                    if($row2[grade] == 10){
                        echo "<li><a class='menus' href='mp3_index.php'>player</a>";
                    }
                ?>
            </ul>
        </nav>
    </div>
</header>
<!-- Header section end -->