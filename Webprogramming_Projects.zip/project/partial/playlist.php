<?php
$connect = mysql_connect("localhost", "game_admin", "123");
mysql_select_db("game_flatform_db", $connect);

    $sql = "select * from playlist;";

    $result = mysql_query($sql, $connect);


?>

<style>
    .bottom-music {
        position: fixed;
        bottom : 0px;
        width : 100%;
    }
</style>


<div class="bottom-music">
    <div class="media-wrapper" >
        <audio id="player2" preload="none" controls width="100%"
               data-cast-title="Jazz Example"
               data-cast-description="This is a description for audio only"
               data-cast-poster="http://mediaelementjs.com/images/big_buck_bunny.jpg">

            <?php
                while($row = mysql_fetch_array($result)){
                    echo "<source src='$row[music_URL]' type='audio/mp3' title='$row[name]'>";
                    //echo "<script>alert($row[music_URL]);</script>";
                }
            ?>


<!--            <source src="https://www.youtube.com/watch?v=_LpGkVXDuaU" type="audio/mp3" title="above all">-->
<!--            <source src="https://www.youtube.com/watch?v=_LpGkVXDuaU" type="audio/mp3" title="above all">-->
<!--            <source src="https://www.youtube.com/watch?v=_LpGkVXDuaU" type="audio/mp3" title="above all">-->
<!--            <source src="https://www.youtube.com/watch?v=_LpGkVXDuaU" type="audio/mp3" title="above all">-->
<!--            <source src="https://www.youtube.com/watch?v=_LpGkVXDuaU" type="audio/mp3" title="above all">-->
<!--            <source src="https://www.youtube.com/watch?v=_LpGkVXDuaU" type="audio/mp3" title="above all">-->
<!---->
<!---->
<!--            <source src="Above All Maranatha.mp3" type="audio/mp3" title="Above all">-->
<!--            <source src="1.mp3" type="audio/mp3" title="1">-->
<!--            <source src="2.wav" type="audio/wav" title="2" >-->
<!--            <source src="https://www.youtube.com/watch?v=_LpGkVXDuaU" type="audio/mp3" title="Still Need You">-->
<!--            <source src="https://www.youtube.com/watch?v=IDjba--EVgs&list=PLtdWdFWSYZKUsUSd2NG_EGVJDDAEyJbXO&index=42" type="audio/mp3" title="수룡화룡">-->
<!--            <source src="https://www.youtube.com/watch?v=lpY6YCsTdFI&list=PLtdWdFWSYZKUsUSd2NG_EGVJDDAEyJbXO&index=43" type="audio/mp3" title="암흑왕의방">-->
<!--            <source src="https://www.youtube.com/watch?v=lpY6YCsTdFI&list=PLtdWdFWSYZKUsUSd2NG_EGVJDDAEyJbXO&index=43" type="audio/mp3" title="닌자의방">-->
<!--            <source src="" type="audio/mp3" title="">-->


        </audio>
    </div>
</div>

<?php
    sleep(2);
    echo "<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.6/mediaelement-and-player.min.js'></script>";
    echo "<script type='text/javascript' src='dist/playlist/playlist.js'></script>";
    echo "<script type='text/javascript' src='partial/player_script.js'></script>";
?>
<!--
<script src="https://cdnjs.cloudflare.com/ajax/libs/mediaelement/4.2.6/mediaelement-and-player.min.js"></script>
<script src="dist/playlist/playlist.js"></script>
<script>
    var mediaElements = document.querySelectorAll('video, audio');

    for (var i = 0, total = mediaElements.length; i < total; i++) {
        new MediaElementPlayer(mediaElements[i], {
            features: ['prevtrack', 'playpause', 'nexttrack', 'current', 'progress', 'duration', 'volume', 'playlist', 'shuffle', 'loop', 'fullscreen'],
        });
    }
</script>
-->