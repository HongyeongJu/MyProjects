<?php
include "server_connect/connect.php";

$sql = "select * from game order by overallScore desc limit 6;";
$rank_Game_Result = mysql_query($sql, $connect);

$sql = "select * from game order by launch_date desc limit 4;";
$recent_Game_Result = mysql_query($sql, $connect);

?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <?php
    include "partial/meta.php";
    ?>

</head>
<body>
<!-- Page Preloder -->
<div id="preloder">
    <div class="loader"></div>
</div>

<?php
include "partial/menu.php";
?>


<!-- Page info section -->
<section class="page-info-section set-bg" data-setbg="img/page-top-bg/3.jpg">
    <div class="pi-content">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-6 text-white">
                    <h2>Games</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Page info section -->


<!-- Page section -->
<section class="page-section review-page spad">
    <div class="container">
        <div class="row">
            <?php
            while($rank_Game = mysql_fetch_array($rank_Game_Result)){
                echo "<div class=\"col-md-6\">
					<div class=\"review-item\">
					<div class=\"score yellow\">$rank_Game[overallScore]</div>
					<a class='game_link' href='game.php?gameid=$rank_Game[game_id]'>
						<div class=\"review-cover set-bg\" data-setbg=$rank_Game[image2_URL]></div></a>
						<div class=\"review-text\">
							<h4><a class='game_link' href='game.php?gameid=$rank_Game[game_id]'>$rank_Game[name]</a></h4>
							<div class=\"rating\">";
                for($i = 0; $i < 5; $i++){
                    $index = $rank_Game[overallScore] / 2;
                    if($i < $index)
                        echo "<i class=\"fa fa-star\"></i>";
                    else
                        echo "<i class=\"fa fa-star is-fade\"></i>";
                }

                echo "</div>
							<p>$rank_Game[description]</p>
						</div>
					</div>
				</div>";
            }

            ?>

        </div>
    </div>
</section>
<!-- Page section end -->


<!-- Review section -->
<section class="review-section review-dark spad set-bg" data-setbg="img/review-bg-2.jpg">
    <div class="container">
        <div class="section-title text-white">
            <div class="cata new">new</div>
            <h2>Recent Reviews</h2>
        </div>
        <div class="row text-white">
            <?php
            while($recent_Game = mysql_fetch_array($recent_Game_Result)){
                echo "<div class=\"col-lg-3 col-md-6\">
					<div class=\"review-item\">
					<div class=\"score pink\">$recent_Game[overallScore]</div>
					<a class='game_link' href='game.php?gameid=$recent_Game[game_id]'>
						<div class=\"review-cover set-bg\" data-setbg=$recent_Game[image3_URL]></div>
						</a>
						<div class=\"review-text\">
							<h5><a class='game_link' href='game.php?gameid=$recent_Game[game_id]'>$recent_Game[name]</a></h5>
							<p>$recent_Game[description]</p>
						</div>
					</div>
				</div>";
            }
            ?>

        </div>
    </div>
</section>
<!-- Review section end -->


<!-- Footer section -->
<footer class="footer-section">
    <div class="container">
        <ul class="footer-menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="sell.php">Games</a></li>
            <li><a href="library.php">Library</a></li>
            <li><a href="community.php">Forums</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
        <p class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
        </p>
    </div>
</footer>
<!-- Footer section end -->


<!--====== Javascripts & Jquery ======-->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.marquee.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>