<?php
    include "server_connect/connect.php";

    $myid = $_SESSION[id];

?>

<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Game Warrior Template</title>
	<meta charset="UTF-8">
	<meta name="description" content="Game Warrior Template">
	<meta name="keywords" content="warrior, game, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    include "partial/meta.php";
    ?>

    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/vendor/perfect-scrollbar/perfect-scrollbar.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="mp3_table/css/util.css">
    <link rel="stylesheet" type="text/css" href="mp3_table/css/main.css">
    <!--===============================================================================================-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

    <?php
    include "partial/menu.php";
    ?>


    <div class="limiter">
        <div class="container-table100">
            <div class="wrap-table100">
                <a href="mp3_index.php" style="border: 1px; padding: 10px; background: #36304a; display: block; width: 100px; text-align: center; border-radius: 10px; margin-bottom: 5px;"> Back </a>
                <?php

                if(isset($_GET[music_id])) {
                    #TODO: MySQL 테이블에서, num에 해당하는 레코드 가져오기

                    $sql = "select * from playlist where music_id=$_GET[music_id];";

                    // echo "$sql";
                    $result = mysql_query($sql,$connect);
                }

                if(isset($_GET[music_id])) {         // $_GET[num] 값이 있는가?
                    echo "<form method=\"POST\" action=\"function/mp3_update.php?music_id=$_GET[music_id]\">";
                } else {
                    echo "<form method=\"POST\" action=\"function/mp3_insert.php\">";
                }
                ?>
                <div class="table100">
                    <table>
                        <thead>
                        <tr class="table100-head">
                            <th class="column2">Name</th>
                            <th class="column3">Music URL</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <?php
                            if(isset($_GET[music_id])) { //update 의 경우!

                                $row = mysql_fetch_array($result);

                                $name = $row[name];
                                $music_url = $row[music_URL];


                                mysql_close();

                                ?>
                                <td class="column2"> <input name="name" type="text" value="<? echo $name; ?>" /> </td>
                                <td class="column3"> <input name="music_url" type="text" value="<? echo $music_url; ?>" /></td>
                                <?php
                            } else {
                                ?>
                                <td class="column1"> <input name="name" type="text" /> </td>
                                <td class="column2"> <input name="music_url" type="text" /> </td>
                                <?php
                            }
                            ?>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <?php
                if(isset($_GET[music_id])) {
                    ?>
                    <a href="function/mp3_delete.php?music_id=<? echo $_GET[music_id] ?>" style="border: 1px; padding: 10px; background: #36304a; display: block; width: 100px; text-align: center; float: right; border-radius: 10px; margin-top: 5px; margin-left: 5px; color: #007bff;"> Delete </a>
                    <input style="border: 1px; padding: 10px; background: #36304a; display: block; width: 100px; text-align: center; float: right; border-radius: 10px; margin-top: 5px; margin-left: 5px; color: #007bff; cursor: pointer;" type="submit" value="Update">
                    <?php
                } else {
                    ?>
                    <input style="border: 1px; padding: 10px; background: #36304a; display: block; width: 100px; text-align: center; float: right; border-radius: 10px; margin-top: 5px; margin-left: 5px; color: #007bff; cursor: pointer;" type="submit" value="Insert">
                    <?php
                }
                ?>
                </form>
            </div>
        </div>
    </div>

	
	<!-- Footer section -->
	<footer class="footer-section">
		<div class="container">
			<ul class="footer-menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="review.html">Games</a></li>
				<li><a href="categories.php">Blog</a></li>
				<li><a href="community.php">Forums</a></li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
			<p class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</p>
		</div>
	</footer>
	<!-- Footer section end -->


	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.marquee.min.js"></script>
	<script src="js/main.js"></script>


    <!--===============================================================================================-->
    <script src="mp3_table/vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="mp3_table/vendor/bootstrap/js/popper.js"></script>
    <script src="mp3_table/vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="mp3_table/vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="mp3_table/js/main.js"></script>



    </body>
</html>