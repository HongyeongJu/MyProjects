-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 19-06-10 01:16 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `game_flatform_db`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `buying`
--

DROP TABLE IF EXISTS `buying`;
CREATE TABLE IF NOT EXISTS `buying` (
  `user_id` char(30) NOT NULL DEFAULT '',
  `game_id` int(11) NOT NULL DEFAULT '0',
  `buy_date` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`user_id`,`game_id`,`buy_date`),
  KEY `user_id` (`user_id`),
  KEY `game_id` (`game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 테이블의 덤프 데이터 `buying`
--

INSERT INTO `buying` (`user_id`, `game_id`, `buy_date`) VALUES
('admin', 1, '2018-05-01'),
('admin', 2, '2018-05-02'),
('admin', 3, '2018-05-03'),
('admin', 5, '2018-05-04');

-- --------------------------------------------------------

--
-- 테이블 구조 `chat`
--

DROP TABLE IF EXISTS `chat`;
CREATE TABLE IF NOT EXISTS `chat` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `msg` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`no`),
  KEY `date` (`date`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- 테이블의 덤프 데이터 `chat`
--

INSERT INTO `chat` (`no`, `name`, `msg`, `date`) VALUES
(1, 'unknown', 'dsadsa', '2019-06-06 18:21:30'),
(2, 'unknown', 'dsadsa', '2019-06-06 18:21:31'),
(3, 'unknown', 'dsadsa', '2019-06-06 18:21:33'),
(4, 'unknown', 'ddasdsadsa', '2019-06-06 18:21:49'),
(5, 'admin', 'dsadsa', '2019-06-06 18:24:10'),
(6, 'admin', 'adsadsa', '2019-06-06 18:24:12'),
(7, 'admin', 'dsadsa', '2019-06-06 18:34:15'),
(8, 'admin', 'dasdsa', '2019-06-06 18:34:16'),
(9, 'admin', 'ddd', '2019-06-06 18:36:23'),
(10, 'unknown', 'dsadsa', '2019-06-06 18:36:50'),
(11, 'unknown', 'dasads', '2019-06-06 18:36:51'),
(12, 'unknown', 'ddd', '2019-06-06 18:37:29'),
(13, 'unknown', 'ddd', '2019-06-06 18:37:30'),
(14, 'unknown', 'dsadsa', '2019-06-06 18:37:39'),
(15, 'unknown', 'dasd', '2019-06-06 18:37:40'),
(16, 'unknown', 'dsad', '2019-06-06 18:37:41'),
(17, 'unknown', 'dasads', '2019-06-06 18:37:42'),
(18, 'unknown', 'dassad', '2019-06-06 18:37:43'),
(19, 'unknown', 'dsads', '2019-06-06 18:37:44'),
(20, 'abc123472000', 'dsadsa', '2019-06-06 18:40:29'),
(21, 'abc123472000', 'daadssa', '2019-06-06 18:40:30'),
(22, 'abc123472000', 'dd', '2019-06-06 18:42:30'),
(23, 'abc123472000', 'daadas', '2019-06-06 18:42:31'),
(24, 'abc123472000', 'addadas', '2019-06-06 18:42:32'),
(25, 'abc123472000', 'dsasadssad', '2019-06-06 18:42:33'),
(26, 'abc123472000', 'dsadsa', '2019-06-06 21:46:43'),
(27, 'abc123472000', 'dsadas', '2019-06-06 21:46:44'),
(28, 'abc123472000', 'dsadas', '2019-06-06 21:46:46'),
(29, 'unknown', 'dsadsa', '2019-06-09 08:22:17'),
(30, 'unknown', 'dsadsa', '2019-06-09 08:22:18'),
(31, 'unknown', 'dsada', '2019-06-09 08:22:20'),
(32, 'abc123472000', 'dasdsa', '2019-06-09 08:24:18'),
(33, 'abc123472000', 'asdsad', '2019-06-09 08:24:19'),
(34, 'abc123472000', 'dd', '2019-06-09 08:25:43'),
(35, 'abc123472000', 'dsadsa', '2019-06-09 08:25:44'),
(36, 'admin', 'dsads', '2019-06-10 01:04:45'),
(37, 'admin', 'dadas', '2019-06-10 01:05:13'),
(38, 'admin', 'www', '2019-06-10 01:07:25'),
(39, 'admin', 'asad', '2019-06-10 01:07:30'),
(40, 'admin', 'adsaas', '2019-06-10 01:07:31');

-- --------------------------------------------------------

--
-- 테이블 구조 `game`
--

DROP TABLE IF EXISTS `game`;
CREATE TABLE IF NOT EXISTS `game` (
  `game_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(50) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `launch_date` date DEFAULT NULL,
  `genre` char(10) NOT NULL,
  `age_limit` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `overallScore` double DEFAULT NULL,
  `image1_URL` varchar(100) DEFAULT NULL,
  `image2_URL` varchar(100) DEFAULT NULL,
  `image3_URL` varchar(100) DEFAULT NULL,
  `image4_URL` varchar(100) DEFAULT NULL,
  `movie_URL` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`game_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- 테이블의 덤프 데이터 `game`
--

INSERT INTO `game` (`game_id`, `name`, `price`, `launch_date`, `genre`, `age_limit`, `description`, `overallScore`, `image1_URL`, `image2_URL`, `image3_URL`, `image4_URL`, `movie_URL`) VALUES
(1, 'Witcher3: Wild Hunt', 34800, '2015-05-18', 'Adventure', 18, 'As war rages on throughout the Northern Realms, you take on the greatest contract of your life tracking down the Child of Prophecy, a living weapon that can alter the shape of the world', 9.5, 'img/game/witcher1.jpg', 'img/game/witcher2.jpg', 'img/game/witcher3.jpg', 'img/game/witcher4.jpg', 'https://www.youtube.com/embed/ehjJ614QfeM'),
(2, 'Monster Hunter: World', 63000, '2018-08-10', 'RPG', 15, 'Welcome to a new world! In Monster Hunter: World, the latest installment in the series, you can enjoy the ultimate hunting experience, using everything at your disposal to hunt monsters in a new world', 7.9, 'img/game/mhw1.jpg', 'img/game/mhw2.jpg', 'img/game/mhw3.jpg', 'img/game/mhw4.jpg', 'https://www.youtube.com/embed/TP7csxTwH5E'),
(3, 'The Elder Scrolls V: Skyrim Special Edition', 46160, '2016-10-28', 'RPG', 18, 'The future of Skyrim, even the Empire itself, hangs in the balance as they wait for the prophesized Dragonborn to come; a hero born with the power of The Voice, and the only one who can stand amongst ', 9.2, 'img/game/skyrim1.jpg', 'img/game/skyrim2.jpg', 'img/game/skyrim3.jpg', 'img/game/skyrim4.jpg', 'https://www.youtube.com/embed/JSRtYpNRoN0'),
(4, 'Sekiro: Shadows Die Twice', 59800, '2019-03-22', 'Adventure', 18, 'Carve your own clever path to vengeance in an all-new adventure from developer FromSoftware, creators of Bloodborne and the Dark Souls series. Take Revenge. Restore your honor. Kill Ingeniously.', 8.8, 'img/game/sekiro1.jpg', 'img/game/sekiro2.jpg', 'img/game/sekiro3.jpg', 'img/game/sekiro4.jpg', 'https://www.youtube.com/embed/rXMX4YJ7Lks'),
(5, 'Devil May Cry 5', 63000, '2019-03-08', 'Action', 18, 'The ultimate Devil Hunter is back in style, in the game action fans have been waiting for.', 7.7, 'img/game/dmc1.jpg', 'img/game/dmc2.jpg', 'img/game/dmc3.jpg', 'img/game/dmc4.jpg', 'https://www.youtube.com/embed/MWxlbnI9mpU'),
(6, 'Sid Meiers Civilization VI', 65000, '2016-10-21', 'Strategy', 12, 'Create, discover, and download new player-created maps, scenarios, interfaces, and more!', 7.3, 'img/game/smc1.jpg', 'img/game/smc2.jpg', 'img/game/smc3.jpg', 'img/game/smc4.jpg', 'https://www.youtube.com/embed/5KdE0p2joJw');

-- --------------------------------------------------------

--
-- 테이블 구조 `playlist`
--

DROP TABLE IF EXISTS `playlist`;
CREATE TABLE IF NOT EXISTS `playlist` (
  `music_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(30) DEFAULT NULL,
  `music_URL` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`music_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- 테이블의 덤프 데이터 `playlist`
--

INSERT INTO `playlist` (`music_id`, `name`, `music_URL`) VALUES
(3, 'organ of soul', 'https://www.youtube.com/watch?v=c1INSJP_Tbg'),
(4, 'BaBaYeTu', 'https://www.youtube.com/watch?v=8vsezgP8rjs'),
(5, 'Sogno di Volare', 'https://www.youtube.com/watch?v=ZrZVD005Szw'),
(6, 'baram', 'https://www.youtube.com/watch?v=IDjba--EVgs&list=PLtdWdFWSYZKUsUSd2NG_EGVJDDAEyJbXO&index=42'),
(7, 'skyrim-ost', 'https://www.youtube.com/watch?v=5OWdMHIRld8&list=PL8CB7943AB56938F8');

-- --------------------------------------------------------

--
-- 테이블 구조 `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` char(30) NOT NULL,
  `name` char(20) NOT NULL,
  `password` char(100) NOT NULL,
  `age` int(11) NOT NULL,
  `sex` int(11) NOT NULL,
  `phone` char(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `grade` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 테이블의 덤프 데이터 `user`
--

INSERT INTO `user` (`user_id`, `name`, `password`, `age`, `sex`, `phone`, `address`, `grade`) VALUES
('abc123472000', 'dd', '123', 0, 0, '01095253360', '1daaas', 1),
('admin', '°ü¸®ÀÚ', '123', 25, 0, '010-0000-0000', '¼­¿ï½Ã °­³²±¸', 10);

-- --------------------------------------------------------

--
-- 테이블 구조 `writing`
--

DROP TABLE IF EXISTS `writing`;
CREATE TABLE IF NOT EXISTS `writing` (
  `board_num` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` char(30) NOT NULL,
  `write_date` datetime NOT NULL,
  `title` varchar(40) NOT NULL,
  `main_text` varchar(300) NOT NULL,
  `file_url` varchar(100) DEFAULT NULL,
  `picture_url` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`board_num`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- 테이블의 덤프 데이터 `writing`
--

INSERT INTO `writing` (`board_num`, `user_id`, `write_date`, `title`, `main_text`, `file_url`, `picture_url`) VALUES
(11, 'abc123472000', '2019-06-10 00:50:17', 'Hello everyone', 'Hello ~~', 'file/', 'images/board/'),
(12, 'abc123472000', '2019-06-10 00:53:57', 'that is Civ6 picture~', 'Civ6 is very fun!! Let''s play it !!', 'file/', 'images/board/img-5cfd2b9544b13.jpg'),
(13, 'abc123472000', '2019-06-10 00:55:23', 'I want to play maple story game!!', 'I want to play it!!!!', 'file/file-5cfd2beb6a8ea.jpg', 'images/board/img-5cfd2beb6a2e5.jpg'),
(14, 'abc123472000', '2019-06-10 00:55:52', 'HeHe ', 'I want to play any game!', 'file/', 'images/board/'),
(15, 'abc123472000', '2019-06-10 00:58:46', 'What is the music name?', 'I want to know !!', 'file/file-5cfd2cb68b851.mp3', 'images/board/');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buying`
--
ALTER TABLE `buying`
  ADD CONSTRAINT `buying_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  ADD CONSTRAINT `buying_ibfk_2` FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`);

--
-- Constraints for table `writing`
--
ALTER TABLE `writing`
  ADD CONSTRAINT `writing_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`);
