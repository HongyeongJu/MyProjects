/*
#include "sound.h"

void playMoveSound() {
	PlaySound("chessmovesound.wav", NULL, SND_SYNC);
	PlaySound(0, 0, 0);
}

*/