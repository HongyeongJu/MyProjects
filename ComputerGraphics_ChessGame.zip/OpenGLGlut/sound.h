/*
#include <Windows.h>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")

void playMoveSound();

*/