#pragma once
#include "Mouse.h"
#include "Position.h"

position findRowCol(const char *str);
void initMaze(int** Maze, const char* str, int row, int col);
void printMaze(int** Maze, int row, int col);
void makeMaze(const char *str, int** Maze, int row, int col); 
void PrintResultToFile(int ** Maze, char *Filename, int row, int col, Mouse mouse);