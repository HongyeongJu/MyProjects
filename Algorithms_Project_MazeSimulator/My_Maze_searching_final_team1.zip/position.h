#pragma once
#include "Mouse.h"
typedef struct position {
	int row;
	int col;
	int direction_list[4] = { 0 };			// [0] : ����, [1] : ����, [2] : ������, [3]: �Ʒ���
	position *Next;

	position(int c = 0, int r = 0) {
		row = r;
		col = c;
	}

	bool isNeighbor(position &p) {
		return((row == p.row && (col == p.col - 1 || col == p.col + 1))
			|| (col == p.col && (row == p.row - 1 || row == p.row + 1)));
	}

	bool operator==(position &p) { return row == p.row && col == p.col; }

	bool isExit(int row, int col, int m_row, int m_col) {
		//printf("row = %d col = %d , m_row = %d, m_col = %d\n", row, col, m_row, m_col);
		if ((!(row == 0 && col == 1)) && (row == (m_row - 1) || col == (m_col - 1) || row == 0 || col == 0)) return true;
		else return false;
	}
};

bool isExit(int row, int col, int m_row, int m_col);
position findDestination(int** Maze, position size);
bool isValidLoc(int** Maze, int r, int c, int maxRow, int maxCol);
void searchSurround(int** Maze, position& now_position, position sizeRowCol);
int countSurround_enable(position now_position);
void suffle(int *arr, int nMax);
position go_at_the_intersection(int* dirction_random, int dirction_size, position now_position);
void GoGo(int** Maze, position sizeRowCol, Mouse& mouse, position& now_position, int criteria, position desti, char *FileName);