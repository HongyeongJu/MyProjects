#pragma once
#include "Position.h"
#include <iostream>
#include <Windows.h>

class stackClass
{
public:
	int pointCol;
	int pointRow;
	int size;

	stackClass();
	stackClass(const stackClass & s);
	~stackClass();

	void Push(int m_row, int m_col);
	void Pop();
	boolean IsEmpty();
	int Size();

	position* Top;

};