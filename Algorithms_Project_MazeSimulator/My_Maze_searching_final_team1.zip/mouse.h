#pragma once 

#include<stdio.h>

struct Mouse
{
	int energy;
	float mana = 0.0f;
};

